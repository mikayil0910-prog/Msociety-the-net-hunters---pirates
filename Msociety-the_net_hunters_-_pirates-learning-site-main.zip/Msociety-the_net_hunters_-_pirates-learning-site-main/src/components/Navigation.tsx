import { Link, useLocation } from "react-router-dom";
import { ShoppingCart, Trophy, User, Shield, Home } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const Navigation = () => {
  const location = useLocation();
  
  const isActive = (path: string) => location.pathname === path;
  
  return (
    <nav className="sticky top-0 z-50 border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <Shield className="h-8 w-8 text-primary" />
            <span className="text-xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              VulnShop
            </span>
            <Badge variant="destructive" className="text-xs">LEARNING</Badge>
          </Link>
          
          <div className="flex items-center space-x-2">
            <Button
              variant={isActive("/") ? "default" : "ghost"}
              size="sm"
              asChild
            >
              <Link to="/">
                <Home className="h-4 w-4 mr-2" />
                Магазин
              </Link>
            </Button>
            
            <Button
              variant={isActive("/challenges") ? "default" : "ghost"}
              size="sm"
              asChild
            >
              <Link to="/challenges">
                <Trophy className="h-4 w-4 mr-2" />
                Челленджи
              </Link>
            </Button>
            
            <Button
              variant={isActive("/cart") ? "default" : "ghost"}
              size="sm"
              asChild
            >
              <Link to="/cart">
                <ShoppingCart className="h-4 w-4 mr-2" />
                Корзина
              </Link>
            </Button>
            
            <Button
              variant={isActive("/auth") ? "default" : "ghost"}
              size="sm"
              asChild
            >
              <Link to="/auth">
                <User className="h-4 w-4 mr-2" />
                Вход
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
