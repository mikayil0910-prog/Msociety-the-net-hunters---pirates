import { useState } from "react";
import Navigation from "@/components/Navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Progress } from "@/components/ui/progress";
import { Lock, Unlock, AlertTriangle, Code, Database, Shield, Eye } from "lucide-react";

const challenges = [
  {
    id: 1,
    category: "XSS",
    icon: Code,
    name: "DOM XSS",
    difficulty: "⭐",
    description: "Выполните DOM-based XSS атаку через поисковую строку",
    hint: "Попробуйте ввести <script>alert('XSS')</script> в поиске",
    solved: false,
    points: 100
  },
  {
    id: 2,
    category: "Injection",
    icon: Database,
    name: "SQL Injection",
    difficulty: "⭐⭐",
    description: "Обойдите аутентификацию используя SQL injection",
    hint: "Попробуйте ' OR '1'='1 в поле логина",
    solved: false,
    points: 150
  },
  {
    id: 3,
    category: "Broken Auth",
    icon: Shield,
    name: "Слабый пароль администратора",
    difficulty: "⭐",
    description: "Найдите и взломайте аккаунт администратора",
    hint: "Попробуйте обычные пароли: admin123, password, 12345",
    solved: false,
    points: 100
  },
  {
    id: 4,
    category: "Access Control",
    icon: Lock,
    name: "Несанкционированный доступ",
    difficulty: "⭐⭐",
    description: "Получите доступ к панели администратора без прав",
    hint: "Проверьте URL и попробуйте /admin напрямую",
    solved: false,
    points: 150
  },
  {
    id: 5,
    category: "Info Disclosure",
    icon: Eye,
    name: "Утечка конфиденциальных данных",
    difficulty: "⭐⭐⭐",
    description: "Найдите скрытую информацию в исходном коде",
    hint: "Проверьте HTML комментарии и JavaScript файлы",
    solved: false,
    points: 200
  },
  {
    id: 6,
    category: "CSRF",
    icon: AlertTriangle,
    name: "Cross-Site Request Forgery",
    difficulty: "⭐⭐⭐",
    description: "Выполните CSRF атаку на форму изменения пароля",
    hint: "Отсутствует CSRF токен в форме",
    solved: false,
    points: 200
  }
];

const Challenges = () => {
  const [solvedChallenges] = useState<number[]>([]);
  
  const totalPoints = challenges.reduce((sum, c) => sum + c.points, 0);
  const earnedPoints = challenges
    .filter(c => solvedChallenges.includes(c.id))
    .reduce((sum, c) => sum + c.points, 0);
  const progress = (earnedPoints / totalPoints) * 100;
  
  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      "XSS": "bg-destructive",
      "Injection": "bg-warning",
      "Broken Auth": "bg-primary",
      "Access Control": "bg-accent",
      "Info Disclosure": "bg-secondary",
      "CSRF": "bg-destructive"
    };
    return colors[category] || "bg-muted";
  };
  
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Челленджи по безопасности
          </h1>
          <p className="text-muted-foreground mb-4">
            Найдите и эксплуатируйте уязвимости для обучения
          </p>
          
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-foreground">Ваш прогресс</CardTitle>
              <CardDescription className="text-muted-foreground">
                {solvedChallenges.length} из {challenges.length} челленджей решено
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Progress value={progress} className="h-2" />
                <p className="text-sm text-muted-foreground text-right">
                  {earnedPoints} / {totalPoints} очков
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid gap-4">
          {challenges.map((challenge) => {
            const Icon = challenge.icon;
            const isSolved = solvedChallenges.includes(challenge.id);
            
            return (
              <Card key={challenge.id} className="border-border hover:border-primary transition-colors">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-lg ${getCategoryColor(challenge.category)}`}>
                        <Icon className="h-5 w-5 text-white" />
                      </div>
                      <div>
                        <div className="flex items-center space-x-2 mb-1">
                          <CardTitle className="text-foreground">{challenge.name}</CardTitle>
                          {isSolved ? (
                            <Unlock className="h-4 w-4 text-success" />
                          ) : (
                            <Lock className="h-4 w-4 text-muted-foreground" />
                          )}
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline" className="text-xs">
                            {challenge.category}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {challenge.difficulty}
                          </span>
                          <Badge variant="secondary" className="text-xs">
                            {challenge.points} pts
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Accordion type="single" collapsible>
                    <AccordionItem value="details" className="border-none">
                      <AccordionTrigger className="text-sm text-muted-foreground hover:text-foreground">
                        Описание и подсказки
                      </AccordionTrigger>
                      <AccordionContent className="space-y-2">
                        <p className="text-sm text-foreground">{challenge.description}</p>
                        <div className="p-3 bg-muted rounded-md">
                          <p className="text-xs text-muted-foreground font-mono">
                            💡 Подсказка: {challenge.hint}
                          </p>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </main>
    </div>
  );
};

export default Challenges;
