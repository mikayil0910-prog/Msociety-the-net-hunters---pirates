import { useState } from "react";
import Navigation from "@/components/Navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertTriangle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const Auth = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { toast } = useToast();
  
  // УЯЗВИМОСТЬ: Отсутствие валидации на клиенте
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    // УЯЗВИМОСТЬ: SQL Injection возможен
    // В реальности это должно быть защищено
    if (email === "admin' OR '1'='1" || password === "admin' OR '1'='1") {
      toast({
        title: "🎉 Челлендж решён!",
        description: "Вы нашли SQL Injection уязвимость!",
        variant: "default"
      });
      return;
    }
    
    // УЯЗВИМОСТЬ: Слабые пароли администратора
    if (email === "admin@vulnshop.com" && password === "admin123") {
      toast({
        title: "🎉 Челлендж решён!",
        description: "Вы взломали аккаунт администратора со слабым паролем!",
        variant: "default"
      });
      return;
    }
    
    toast({
      title: "Ошибка входа",
      description: "Неверный email или пароль",
      variant: "destructive"
    });
  };
  
  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    
    // УЯЗВИМОСТЬ: Отсутствие проверки сложности пароля
    if (password.length < 3) {
      toast({
        title: "Регистрация успешна",
        description: "Вы зарегистрированы со слабым паролем!",
      });
      return;
    }
    
    toast({
      title: "Регистрация успешна",
      description: "Аккаунт создан",
    });
  };
  
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-md mx-auto">
          <div className="mb-8 text-center">
            <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Вход в систему
            </h1>
            <p className="text-muted-foreground">
              Попробуйте найти уязвимости в аутентификации
            </p>
          </div>
          
          <Alert className="mb-6 border-destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <strong>Учебная среда:</strong> Эта форма содержит уязвимости для обучения. 
              Попробуйте SQL injection или слабые пароли!
            </AlertDescription>
          </Alert>
          
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">Вход</TabsTrigger>
              <TabsTrigger value="signup">Регистрация</TabsTrigger>
            </TabsList>
            
            <TabsContent value="login">
              <Card className="border-border">
                <CardHeader>
                  <CardTitle className="text-foreground">Войти в аккаунт</CardTitle>
                  <CardDescription className="text-muted-foreground">
                    Введите ваши данные для входа
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleLogin} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="login-email">Email</Label>
                      <Input
                        id="login-email"
                        type="text"
                        placeholder="email@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="login-password">Пароль</Label>
                      <Input
                        id="login-password"
                        type="password"
                        placeholder="••••••••"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                      />
                    </div>
                    
                    <Button type="submit" className="w-full">
                      Войти
                    </Button>
                    
                    <div className="text-xs text-muted-foreground space-y-1 mt-4">
                      <p>💡 Подсказки:</p>
                      <p>• Попробуйте: admin@vulnshop.com / admin123</p>
                      <p>• SQL Injection: admin' OR '1'='1</p>
                    </div>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="signup">
              <Card className="border-border">
                <CardHeader>
                  <CardTitle className="text-foreground">Создать аккаунт</CardTitle>
                  <CardDescription className="text-muted-foreground">
                    Зарегистрируйтесь для доступа
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSignup} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="signup-email">Email</Label>
                      <Input
                        id="signup-email"
                        type="text"
                        placeholder="email@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="signup-password">Пароль</Label>
                      <Input
                        id="signup-password"
                        type="password"
                        placeholder="••••••••"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                      />
                    </div>
                    
                    <Button type="submit" className="w-full">
                      Зарегистрироваться
                    </Button>
                    
                    <div className="text-xs text-muted-foreground mt-4">
                      <p>💡 Подсказка: Попробуйте создать аккаунт с очень слабым паролем (например "123")</p>
                    </div>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
};

export default Auth;
