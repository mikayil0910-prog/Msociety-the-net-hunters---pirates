import Navigation from "@/components/Navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ShoppingBag } from "lucide-react";

const Cart = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-8 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
          Корзина
        </h1>
        
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="text-foreground">Ваша корзина пуста</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <ShoppingBag className="h-24 w-24 text-muted-foreground mb-4" />
            <p className="text-muted-foreground mb-6">
              Добавьте товары из магазина
            </p>
            <Button asChild>
              <a href="/">Перейти в магазин</a>
            </Button>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default Cart;
