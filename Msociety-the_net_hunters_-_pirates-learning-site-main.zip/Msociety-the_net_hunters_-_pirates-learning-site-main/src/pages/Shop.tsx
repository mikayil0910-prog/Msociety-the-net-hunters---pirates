import { useState } from "react";
import Navigation from "@/components/Navigation";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, ShoppingCart, Star } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const mockProducts = [
  {
    id: 1,
    name: "Apple Juice (1000ml)",
    price: 1.99,
    description: "Свежий яблочный сок",
    image: "🧃",
    rating: 4.5,
    vulnerable: true
  },
  {
    id: 2,
    name: "Raspberry Juice (1000ml)",
    price: 2.99,
    description: "Натуральный малиновый сок",
    image: "🧃",
    rating: 4.7,
    vulnerable: false
  },
  {
    id: 3,
    name: "Lemon Juice (500ml)",
    price: 1.49,
    description: "Освежающий лимонный сок",
    image: "🍋",
    rating: 4.2,
    vulnerable: true
  },
  {
    id: 4,
    name: "Banana Juice (1000ml)",
    price: 2.49,
    description: "Экзотический банановый сок",
    image: "🍌",
    rating: 4.0,
    vulnerable: false
  },
  {
    id: 5,
    name: "OWASP SSL Advanced Forensic Tool (2.0.0)",
    price: 0.01,
    description: "Инструмент для анализа SSL",
    image: "🔒",
    rating: 5.0,
    vulnerable: true
  },
  {
    id: 6,
    name: "Christmas Super-Surprise-Box (2025 Edition)",
    price: 29.99,
    description: "Секретная коробка с сюрпризами",
    image: "🎁",
    rating: 4.9,
    vulnerable: true
  }
];

const Shop = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();
  
  // УЯЗВИМОСТЬ: Небезопасный поиск (SQL Injection симуляция)
  const filteredProducts = mockProducts.filter(product => {
    // В реальном приложении это было бы уязвимо к SQL injection
    return product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
           product.description.toLowerCase().includes(searchQuery.toLowerCase());
  });
  
  const handleAddToCart = (productName: string) => {
    toast({
      title: "Добавлено в корзину",
      description: `${productName} добавлен в вашу корзину`,
    });
  };
  
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Добро пожаловать в VulnShop
          </h1>
          <p className="text-muted-foreground">
            Платформа для обучения кибербезопасности с реальными уязвимостями
          </p>
        </div>
        
        <div className="mb-6 relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Поиск товаров... (попробуйте SQL injection)"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map((product) => (
            <Card key={product.id} className="hover:shadow-lg transition-shadow border-border">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="text-6xl mb-2">{product.image}</div>
                  {product.vulnerable && (
                    <Badge variant="destructive" className="text-xs">
                      VULNERABLE
                    </Badge>
                  )}
                </div>
                <CardTitle className="text-foreground">{product.name}</CardTitle>
                <CardDescription className="text-muted-foreground">
                  {product.description}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-1 mb-2">
                  <Star className="h-4 w-4 fill-warning text-warning" />
                  <span className="text-sm text-foreground">{product.rating}</span>
                </div>
                <p className="text-2xl font-bold text-primary">${product.price}</p>
              </CardContent>
              <CardFooter>
                <Button 
                  className="w-full" 
                  onClick={() => handleAddToCart(product.name)}
                >
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  В корзину
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
        
        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground text-lg">Товары не найдены</p>
          </div>
        )}
      </main>
    </div>
  );
};

export default Shop;
